from django.http import HttpResponseRedirect
from django.views.decorators.csrf import csrf_exempt
from BookyBotApp.models import *
# from BookyBotApp.utils import *

from django.shortcuts import render, HttpResponse, get_object_or_404
from django.contrib.auth import logout, authenticate, login
from django.contrib.auth.decorators import login_required

# from rest_framework.response import Response
# from rest_framework import status
# from rest_framework.views import APIView
# from rest_framework.authentication import SessionAuthentication, BasicAuthentication

from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.authentication import SessionAuthentication, BasicAuthentication

from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.core.paginator import Paginator

import requests
import json
import os
import uuid

from chatterbot import ChatBot
from textblob import TextBlob
from textblob import classifiers
from chatterbot.trainers import ChatterBotCorpusTrainer
import json
import pandas as pd

from . import extract_info
from . import flight_api
from . import extraction_json

df = pd.read_csv(os.getcwd()+'/BookyBotApp/flightdata.csv')

training = [
    ("I do not want help", "neg"),
    ("I need no help", "neg"),
    ("Not needed", "neg"),
    ("Nope", "neg"),
    ("Yes", "pos"),
    ("Sure", "pos"),
    ("I would like that", "pos"),
    ("Yes, I need help", "pos"),
    ("I am in need of help", "pos"),
    ("I don't want your help", "neg"),
    ("I think I am fine on my own", "neg"),
    ("In need of help", "pos"),
    ("No its okay", "neg")
]
classifier = classifiers.NaiveBayesClassifier(training)

class CsrfExemptSessionAuthentication(SessionAuthentication):

    def enforce_csrf(self, request):
        return

# Create your views here.
@login_required(login_url='/login/')
def Home(request):
    booky_bot_user = BookyBotUser.objects.get(username=request.user.username)
    booky_bot_user.step_counter=0
    booky_bot_user.trail_flag=0
    booky_bot_user.v_destination=""
    booky_bot_user.v_source=""
    booky_bot_user.v_date=""
    booky_bot_user.save()
    return render(request, 'home.html')

@login_required(login_url='/login/')
def Logout(request):
    logout(request)
    return HttpResponseRedirect('/login/')

def LogIn(request):
    return render(request, 'login.html')

class LogInSubmitAPI(APIView):

    authentication_classes = (
           CsrfExemptSessionAuthentication, BasicAuthentication)

    def post(self, request, *args, **kwargs):

       response = {}
       response['status'] = 500
       try:

           data = request.data

           username = data['username']
           password = data['password']

           user = authenticate(username=username, password=password)

           login(request, user)

           booky_bot_user = BookyBotUser.objects.get(username=username)
           booky_bot_user.step_counter=0
           booky_bot_user.trail_flag=0
           booky_bot_user.v_destination=""
           booky_bot_user.v_source=""
           booky_bot_user.v_date=""
           booky_bot_user.save()


           response['status'] = 200

       except Exception as e:
           print("Error LogInSubmitAPI", str(e))

       return Response(data=response)

class GetResponseAPI(APIView):

    authentication_classes = (
           CsrfExemptSessionAuthentication, BasicAuthentication)

    def post(self, request, *args, **kwargs):

       response = {}
       response['status'] = 500
       try:

            data = request.data
            userText = data["user-msg"]
            print(userText)
            blob_text = TextBlob(userText, classifier=classifier)

            booky_bot_user = BookyBotUser.objects.get(username=request.user.username)
            booky_bot_user.step_counter=booky_bot_user.step_counter+1
            #booky_bot_user.save()
        

            #print(booky_bot_user.step_counter)
            if (booky_bot_user.step_counter == 1):
                if(blob_text.classify() == "pos"):
                    booky_bot_user.trail_flag=1
                    response['bot-msg']="Do you want to book  a ticket?"
                else:
                    booky_bot_user.trail_flag=0
                    response['bot-msg']='Okay. You can always say "Help Me" if you need my assistance.'
                

            if(booky_bot_user.trail_flag==1):
                if(booky_bot_user.step_counter==2):
                    if (blob_text.classify() == "pos"):
                        response['bot-msg']="Enter city name from where you want to travel."
                    else:
                        booky_bot_user.trail_flag = 0
                        response['bot-msg']='Okay. You can always say "Help Me" if you need my assistance.'
                elif(booky_bot_user.step_counter==3):
                    print(source_dest_check(userText,df))
                    if source_dest_check(userText,df) == True:
                        booky_bot_user.v_source = str(userText).lower()
                        response['bot-msg']='Enter destination city where you want to go'
                    else:
                        booky_bot_user.step_counter = booky_bot_user.step_counter - 1
                        response['bot-msg']='Enter a valid source city'
                elif(booky_bot_user.step_counter==4):
                    if source_dest_check(userText,df) == True:
                        booky_bot_user.v_destination = str(userText).lower()
                        response['bot-msg']='Enter travel date'
                    else:
                        booky_bot_user.step_counter = booky_bot_user.step_counter - 1
                        response['bot-msg']="Enter a valid destination City"
                elif(booky_bot_user.step_counter==5):
                    booky_bot_user.v_date = userText
                    #api_integration(source,destination,date)
                    response['bot-msg']="Fetching options"
                elif(booky_bot_user.step_counter==6):
                    if (blob_text.classify() == "neg"):
                        response['bot-msg']="Thank You for using our service. Come next time."

            elif(booky_bot_user.trail_flag==0 and booky_bot_user.step_counter!=1):
                arr_temp = extract_info.blob_search(userText)
                print(arr_temp)
                if all(''==s or s.isspace() for s in arr_temp):
                    booky_bot_user.step_counter = 2
                    booky_bot_user.trail_flag = 1
                    response['bot-msg']='Enter city from where you want to travel.'
                elif(arr_temp[1]=='' and arr_temp[2]==''):
                    booky_bot_user.step_counter = 3
                    booky_bot_user.trail_flag = 1
                    booky_bot_user.v_destination = arr_temp[0]
                    response['bot-msg']='Enter city where you want to go'
                elif(arr_temp[0]=='' and arr_temp[2]==''):
                    booky_bot_user.step_counter = 3
                    booky_bot_user.trail_flag = 1
                    booky_bot_user.v_source = arr_temp[1]
                    response['bot-msg']='Enter city from where you want to travel.'
                elif(arr_temp[0]==''):
                    booky_bot_user.v_destination = arr_temp[1]
                    bbooky_bot_user.v_date = arr_temp[2]
                    booky_bot_user.step_counter = 4
                    booky_bot_user.trail_flag = 1
                    response['bot-msg']='Enter city from where you want to travel.'
                elif(arr_temp[2]==''):
                    booky_bot_user.v_source = arr_temp[0]
                    booky_bot_user.v_destination = arr_temp[1]
                    booky_bot_user.step_counter = 4
                    booky_bot_user.trail_flag = 1
                    response['bot-msg']='Enter travel date'
                elif not any(''==s or s.isspace() for s in arr_temp):
                    booky_bot_user.v_source = arr_temp[0]
                    booky_bot_user.v_destination = arr_temp[1]
                    booky_bot_user.v_date = arr_temp[2]
                    response['bot-msg']='Fetching options'



            booky_bot_user.save()
            print(booky_bot_user.step_counter)
            print(response['bot-msg'])
            response['status'] = 200

       except Exception as e:
           print("Error GetResponseAPI", str(e))

       return Response(data=response)

class FetchFlightAPI(APIView):
    authentication_classes = (
           CsrfExemptSessionAuthentication, BasicAuthentication)

    def post(self, request, *args, **kwargs):

       response = {}
       response['status'] = 500
       try:


            booky_bot_user = BookyBotUser.objects.get(username=request.user.username)
            
            if booky_bot_user.v_source == booky_bot_user.v_destination:
                response1 = {}
                response1["flight_detail"] = "no"
                json_response = json.dumps(response1)
                response["flight_detail"]=json_response #think better logic for this
            else:
               
                src_code = df.loc[df['City'] == booky_bot_user.v_source]['Code'].iloc[0]
                dest_code = df.loc[df['City'] == booky_bot_user.v_destination]['Code'].iloc[0]
                date = booky_bot_user.v_date
                list_sorted =  flight_api.parse_my(src_code, dest_code, date)
                #list_sorted = sorted(list_sorted, key=lambda k: k['ticket price'], reverse=False)
                
                flight_details = extraction_json.flight_data(list_sorted)
                print(flight_details)
                response1 = {}
                response1["flight_detail"] = flight_details
                json_response = json.dumps(response1)
                print(list_sorted[:7])
                response["flight_detail"]=json_response
        #return flight_details

            response['status'] = 200

       except Exception as e:
           print("Error FetchFlightAPI", str(e))

       return Response(data=response)
def source_dest_check(city,df):
    city = str(city).lower()
    list1 = df['City'].to_list()
    if city in list1:
        return True
    else:
        return False


LogInSubmit = LogInSubmitAPI.as_view()
GetResponse = GetResponseAPI.as_view()
FetchFlight = FetchFlightAPI.as_view()

